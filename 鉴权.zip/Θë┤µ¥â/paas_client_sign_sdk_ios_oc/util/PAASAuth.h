//
//  PAASAuth.h
//  paas_client_sign_sdk_ios_oc
//
//  Created by 李浩良 on 2019/12/2.
//  Copyright © 2019 tal. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PAASAuth : NSObject

@property (nonatomic, strong) NSString * contentType;

@property (nonatomic,strong) NSString * request_method;

@property (nonatomic,strong) NSString * urlEncode;

+ (NSString*) getSign:(NSString*)accesskeyId secret:(NSString*) accesskeySecret timestamp:(NSString*) timestamp url:(NSString*) url urlParam:(NSMutableDictionary*)urlparam httpBody:(NSString*)httpBody contentType:(NSString*) contentType method:(NSString*) request_method urlencode:(NSString*)urlEncode;

+ (NSString*) getTime;


@end

NS_ASSUME_NONNULL_END
