//
//  PAASAuth.m
//  paas_client_sign_sdk_ios_oc
//
//  Created by 李浩良 on 2019/12/2.
//  Copyright © 2019 tal. All rights reserved.
//

#import "PAASAuth.h"
#include <CommonCrypto/CommonDigest.h>
#include <CommonCrypto/CommonHMAC.h>
#import <SocketRocket/SRWebSocket.h>
#import "Masonry.h"
#import "CocoaSecurity.h"
#import "AFNetworking.h"
#import <FBSDKCoreKit/FBSDKUtility.h>


@interface PAASAuth ()


//@property (nonatomic, strong) NSString * contentType;
//
//@property (nonatomic,strong) NSString * request_method;
//
//@property (nonatomic,strong) NSString * urlEncode;

@end


@implementation PAASAuth














//HmacSHA1加密；
+ (NSString *)HmacSha1:(NSString *)key data:(NSString *)data
{
    const char *cKey  = [key cStringUsingEncoding:NSUTF8StringEncoding];
    const char *cData = [data cStringUsingEncoding:NSUTF8StringEncoding];
    printf("\ncdata is %s",cData);
//    //Sha256:
//    // unsigned char cHMAC[CC_SHA256_DIGEST_LENGTH];
//    //CCHmac(kCCHmacAlgSHA256, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    //sha1
    unsigned char cHMAC[CC_SHA1_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA1, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    NSData *HMAC = [[NSData alloc] initWithBytes:cHMAC
                                          length:sizeof(cHMAC)];
    NSString *hash = [HMAC base64EncodedStringWithOptions:0];//将加密结果进行一次BASE64编码。
    return hash;
}

//获取当前时间
+(NSString*)getTime{
    NSDate *date = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    formatter.timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    NSString *dateStr = [formatter stringFromDate:date];
    NSString *str =[dateStr stringByReplacingOccurrencesOfString:@" "withString:@"T"];
    NSLog(@"字符串时间 = %@", str);
    return str;
}


//获取sign
+ (NSString*) getSign:(NSString*)accesskeyId secret:(NSString*) accesskeySecret timestamp:(NSString*) timestamp url:(NSString*) url urlParam:(NSMutableDictionary*)urlparam httpBody:(NSString*)httpBody contentType:(NSString*) contentType method:(NSString*) request_method urlencode:(NSString*)urlEncode{
    if(accesskeyId ==nil || accesskeyId.length ==0){
        NSLog(@"参数access_key_id不能为空");
        return nil;
    }
    if(accesskeySecret ==nil || accesskeySecret.length ==0){
        NSLog(@"参数accesskeySecret不能为空");
        return nil;
    }
    if(timestamp ==nil || timestamp.length ==0){
        NSLog(@"参数timestamp不能为空");
        return nil;
    }
    if(url ==nil || url.length ==0){
        NSLog(@"参数url不能为空");
        return nil;
    }
    if(urlparam == nil){
        NSLog(@"参数urlparam不能为空");
        return nil;
    }
    
    if(contentType == nil){
        NSLog(@"参数contentType不能为空");
        return nil;
    }
    
    if(request_method == nil){
        NSLog(@"参数request_method不能为空");
        return nil;
    }

    
    [urlparam setObject:accesskeyId forKey:@"access_key_id"];
    [urlparam setObject:timestamp forKey:@"timestamp"];
    NSString * signature_nonce = [[NSUUID UUID] UUIDString];
    NSMutableDictionary *sign_param = [NSMutableDictionary dictionary];
    [sign_param setDictionary:urlparam];
    [sign_param setObject:signature_nonce forKey:@"signature_nonce"];
    
    if(httpBody!=nil && httpBody.length!=0 &&([request_method isEqualToString:@"POST"] || [request_method isEqualToString:@"PATCH"] || [request_method isEqualToString:@"PUT"]) ){
        if([contentType isEqualToString:@"application/x-www-form-urlencoded"]){
            [sign_param setObject:urlEncode forKey:@"request_body"];
        }else if([contentType isEqualToString:@"application/json"]){
            [sign_param setObject:httpBody forKey:@"request_body"];
        }
    }
    
    NSString* strParam = @"";
    NSArray *keysArray = [sign_param allKeys];
    NSSortDescriptor *sd = [[NSSortDescriptor alloc] initWithKey:nil ascending:YES];
    keysArray = [keysArray sortedArrayUsingDescriptors:@[sd]];
    for (int i = 0; i < keysArray.count; i++) {
        NSString *key = keysArray[i];
       //根据键值获取字典中的每一项
        NSString *value = sign_param[key];
        strParam = [strParam stringByAppendingFormat:@"%@=%@&", key,value];
    }
    strParam = [strParam substringToIndex:strParam.length-1];//截取掉下标之后的字符串
    NSLog(@"截取的值为：%@",strParam);
    accesskeySecret =  [accesskeySecret stringByAppendingFormat:@"&"];
    
    NSString* signature = [PAASAuth HmacSha1:accesskeySecret data:strParam];
    
    NSLog(@"\nhmacsha1 signature is : %@",signature);
    NSString* encodedUrl = [signature stringByReplacingOccurrencesOfString:@"="withString:@"%3D"];
    encodedUrl = [encodedUrl stringByReplacingOccurrencesOfString:@"+"withString:@"%2B"];
    encodedUrl = [encodedUrl stringByReplacingOccurrencesOfString:@"/"withString:@"%2F"];

//    NSCharacterSet *c = [NSCharacterSet characterSetWithCharactersInString:@"'();:@&=+$,/?%#[]"];
//    NSString* encodedUrl = [signature stringByAddingPercentEncodingWithAllowedCharacters:c];
    NSLog(@"\nencode signature is: %@",encodedUrl);
    
    [sign_param setObject:encodedUrl forKey:@"signature"];
    NSMutableDictionary *retHeader = [NSMutableDictionary dictionary];
    [retHeader setObject:accesskeyId forKey:@"access_key_id"];
    [retHeader setObject:signature forKey:@"signature"];
    [retHeader setObject:signature_nonce forKey:@"signature_nonce"];
    [retHeader setObject:timestamp forKey:@"timestamp"];
    NSString* strParam2 = @"";
    NSArray *keysArray2 = [retHeader allKeys];
    NSSortDescriptor *sd2 = [[NSSortDescriptor alloc] initWithKey:nil ascending:YES];
    keysArray2 = [keysArray2 sortedArrayUsingDescriptors:@[sd2]];
    for (int i = 0; i < keysArray2.count; i++) {
        NSString *key = keysArray2[i];
       //根据键值获取字典中的每一项
        NSString *value = sign_param[key];
        strParam2 = [strParam2 stringByAppendingFormat:@"%@=%@&", key,value];
    }
    strParam2 = [strParam2 substringToIndex:strParam2.length-1];//截取掉下标之后的字符串
    NSLog(@"urladd为：%@",strParam2);

    url = [url stringByAppendingString:strParam2];
    NSLog(@"url is :%@",url);
    return url;
}




@end
