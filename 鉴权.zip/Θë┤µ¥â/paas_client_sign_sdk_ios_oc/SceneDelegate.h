//
//  SceneDelegate.h
//  paas_client_sign_sdk_ios_oc
//
//  Created by 李浩良 on 2019/12/2.
//  Copyright © 2019 tal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

