//
//  ViewController.m
//  paas_client_sign_sdk_ios_oc
//
//  Created by 李浩良 on 2019/12/2.
//  Copyright © 2019 tal. All rights reserved.
//

#import "ViewController.h"
#include <CommonCrypto/CommonDigest.h>
#include <CommonCrypto/CommonHMAC.h>
#import <SocketRocket/SRWebSocket.h>
#import "Masonry.h"
#import "CocoaSecurity.h"
#import "AFNetworking.h"
#import <FBSDKCoreKit/FBSDKUtility.h>
//#import "PAASAuth.h"
#import "util/PAASAuth.h"

@interface ViewController ()<SRWebSocketDelegate>


@property (nonatomic, strong) NSString * contentType;

@property (nonatomic,strong) NSString * request_method;

@property (nonatomic,strong) NSString * urlEncode;

@property(nonatomic, strong)SRWebSocket *webSocket;

@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    //basic config
//    NSString* url = @"http://10.1.65.215:8769/aisvcdemo/postJson?";    //http test
//    NSString* url = @"ws://10.1.65.168:8769/aisvcdemo/aiwebsocket?";    //websocket test
    NSString* url = @"http://10.1.65.168:8769/aisvcdemo/postJson?";       //form-data
    //鉴权参数配置
    //http
    NSString *access_key_secret = @"13ad1acbf79a4c3cbeaba5e12d3f9ccd";
    NSString *access_key_id = @"4381305305940992";
    //websocket
//    NSString A*access_key_secret = @"13ad1acbf79a4c3cbeaba5e12d3f9ccd";
//    NSString *access_key_id = @"4381305305940992";
    
    
    
//    self.contentType = @"application/json";
//    self.contentType = @"application/x-www-form-urlencoded";
    self.contentType = @"multipart/form-data";
//    self.contentType = @"websocket";
    self.request_method = @"POST";
    
    NSString* timestamp = [PAASAuth getTime];
    
    
    //user param
    NSMutableDictionary *urlParam = [NSMutableDictionary dictionary];
    NSDictionary *params = @{@"a":@"123",@"b":@"哈哈哈",@"c":@"english"};
   
    NSString* strJson = @"";
    if([self.contentType isEqualToString:@"application/x-www-form-urlencoded"]){
        self.urlEncode = [FBSDKUtility queryStringWithDictionary:params error:nil];
    }

    BOOL isValidJSONObject =  [NSJSONSerialization isValidJSONObject:params];
    if (isValidJSONObject) {
        NSData *data =  [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
        strJson =[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",strJson);
        
        url = [PAASAuth getSign:access_key_id secret:access_key_secret timestamp:timestamp url:url urlParam:urlParam httpBody:strJson contentType: self.contentType method: self.request_method urlencode:self.urlEncode];
    }
    NSLog(@"urlnew is %@",url);
    
    
    
//    test post json body
    if([self.contentType isEqualToString:@"application/json"]){
        NSData *postData = [strJson dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
        AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
        NSMutableURLRequest *request = [[AFJSONRequestSerializer serializer] requestWithMethod:@"POST" URLString:url parameters:nil error:nil];
        request.timeoutInterval= [[[NSUserDefaults standardUserDefaults] valueForKey:@"timeoutInterval"] longValue];
        [request setValue:self.contentType forHTTPHeaderField:@"Content-Type"];
        [request setHTTPBody:postData];
        [[manager dataTaskWithRequest:request completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
            if (!error) {
                NSLog(@"responseObject: %@", responseObject);
            } else {
                NSLog(@"error: %@, %@, %@", error, response, responseObject);
            }
        }] resume];
    }
    
//    //test post x-www-form-urlencoded
    if([self.contentType isEqualToString:@"application/x-www-form-urlencoded"]){
        AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
        [manager.requestSerializer setValue:@"application/x-www-form-urlencoded; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
            manager.requestSerializer = [AFHTTPRequestSerializer serializer];
        [manager POST:url parameters:params progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSLog(@"%@",responseObject);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@",error);
        }];
    }
    
    //test form-data
    if([self.contentType isEqualToString:@"multipart/form-data"]){
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
        
        AFHTTPSessionManager *manage = [AFHTTPSessionManager manager];
        [manage.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        manage.requestSerializer = [AFHTTPRequestSerializer serializer];
        manage.responseSerializer = [AFHTTPResponseSerializer serializer];
        manage.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/json", @"text/javascript",@"text/plain", nil];

        [manage POST:url parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
            //当提交一张图片或一个文件的时候 name 可以随便设置，服务端直接能拿到，如果服务端需要根据name去取不同文件的时候，则appendPartWithFileData 方法中的 name 需要根据form的中的name一一对应
            [formData appendPartWithFormData:jsonData name:@"UploadData"];
        } progress:^(NSProgress * _Nonnull uploadProgress) {
            NSLog(@"process");
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *responseDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            NSLog(@"success:%@",responseObject);
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"failed");
        }];
        
    }
    
    
    
    
    
    
    //test websocket
    if([self.contentType isEqualToString:@"websocket"]){
        _webSocket.delegate = nil;
        [_webSocket close];
        NSMutableURLRequest* request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:url]];
        _webSocket = [[SRWebSocket alloc] initWithURLRequest:request];
        _webSocket.delegate = self;
        NSLog(@"Opening Connection...");
        [_webSocket open];
    }
    
    
    
    
    
}

// 协议方法 链接成功 给服务器发送id
- (void)webSocketDidOpen:(SRWebSocket *)webSocket {
    NSLog(@"Websocket Connected");
}

- (void)webSocket:(SRWebSocket *)webSocket didReceiveMessage:(id)message {
    NSLog(@"接收的消息:%@", message);
    
//     if (message == nil) {
//            return nil;
//        }
    NSData *jsonData = [message dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    NSString *str = [dic objectForKey:@"code"];
    NSLog(@"str = %@",str);
}


@end
